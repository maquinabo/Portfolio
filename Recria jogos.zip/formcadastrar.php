<!DOCTYPE html>
<html class="html" lang="pt-BR">
 <head>

  <script type="text/javascript">
   if(typeof Muse == "undefined") window.Muse = {}; window.Muse.assets = {"required":["jquery-1.8.3.min.js", "museutils.js", "jquery.musepolyfill.bgsize.js", "jquery.scrolleffects.js", "jquery.musemenu.js", "jquery.watch.js", "webpro.js", "formcadastrar.css"], "outOfDate":[]};
</script>
  
  <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
  <meta name="generator" content="2015.0.0.309"/>
    <link rel="shortcut icon" href="images/in%c3%adcio-favicon.ico?3913429556"/>
  <title>Cadastrar</title>
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="css/site_global.css?4052507572"/>
  <link rel="stylesheet" type="text/css" href="css/formcadastrar.css?4070511550" id="pagesheet"/>
  <!-- Other scripts -->
  <script type="text/javascript">
   document.documentElement.className += ' js';
</script>
  <!-- JS includes -->
  <!--[if lt IE 9]>
  <script src="scripts/html5shiv.js?4241844378" type="text/javascript"></script>
  <![endif]-->
   </head>
 <body class="museBGSize">

  <div class="clearfix" id="page"><!-- group -->
   <div class="clearfix grpelem" id="ppu18819"><!-- column -->
    <div class="clearfix colelem" id="pu18819"><!-- group -->
     <div class="mse_pre_init" id="u18819" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-1,M12=0,M21=0,M22=-1,SizingMethod='auto expand')" data-mu-ie-matrix-dx="0" data-mu-ie-matrix-dy="0"><!-- rasterized frame -->
      <img id="u18819_img" alt="" width="1200" height="619" src="images/papernovo-u18819.png"/>
     </div>
     <img class="mse_pre_init ose_pre_init" id="u18878" alt="" width="222" height="197" src="images/logo%20mais%20novo%20que%20tudo23-u18878.png"/><!-- rasterized frame -->
     <img class="mse_pre_init ose_pre_init" id="u18880" alt="" width="155" height="139" src="images/logo%20mais%20novo%20que%20tudo23-u18880.png"/><!-- rasterized frame -->
    </div>
    <nav class="MenuBar clearfix ose_pre_init mse_pre_init" id="menuu18821"><!-- horizontal box -->
     <div class="MenuItemContainer clearfix grpelem" id="u24904"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u24905" href="index.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u24908" alt="Início" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18871"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18874" href="novidades.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18876" alt="Novidades" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18857"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18867" href="jogos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18870" alt="Jogos" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u18869"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u18858"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u18859"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u21912"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u21913" href="sobre-os-jogos.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u21914-4"><!-- rasterized frame --><div id="u21914-4_clip"><img id="u21914-4_img" alt="Sobre os Jogos" width="156" height="33" src="images/u21914-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18829"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18830" href="personagens.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18833" alt="Personagens" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u18832"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u18834"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u18835"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u20687"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u20690" href="sobre-os-personagens.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u20691-4"><!-- rasterized frame --><div id="u20691-4_clip"><img id="u20691-4_img" alt="Sobre os Personagens" width="214" height="31" src="images/u20691-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u24138"><!-- vertical box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u24141" href="sobre-nos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u24142" alt="Sobre Nós" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18850"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18851" href="compras.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18854" alt="Compras" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
    </nav>
    <nav class="MenuBar clearfix ose_pre_init mse_pre_init" id="menuu18882"><!-- horizontal box -->
     <div class="MenuItemContainer clearfix grpelem" id="u24918"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u24919" href="index.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u24920" alt="Início" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18918"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18921" href="novidades.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18924" alt="Novidades" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18883"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18893" href="jogos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18896" alt="Jogos" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u18895"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u18884"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u18885"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u21898"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u21899" href="sobre-os-jogos.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u21902-4"><!-- rasterized frame --><div id="u21902-4_clip"><img id="u21902-4_img" alt="Sobre os Jogos" width="145" height="31" src="images/u21902-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18925"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18926" href="personagens.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18928" alt="Personagens" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u18929"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u18930"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u18931"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u20673"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u20674" href="sobre-os-personagens.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u20675-4"><!-- rasterized frame --><div id="u20675-4_clip"><img id="u20675-4_img" alt="Sobre os Personagens" width="214" height="31" src="images/u20675-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u24208"><!-- vertical box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u24209" href="sobre-nos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u24210" alt="Sobre Nós" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18904"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18905" href="compras.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18906" alt="Compras" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
    </nav>
    <div class="mse_pre_init" id="u25404"><!-- simple frame --></div>
    <a class="nonblock nontext rounded-corners mse_pre_init" id="u25405" href="https://www.facebook.com/recriajogos"><!-- simple frame --></a>
    <a class="nonblock nontext museBGSize mse_pre_init" id="u25406" href="https://twitter.com/recriajogos"><!-- simple frame --></a>
    <a class="nonblock nontext museBGSize mse_pre_init" id="u25407" href="https://www.youtube.com/channel/UCy1YqCHq2qD1-eH30qrFOlA"><!-- simple frame --></a>
    <a class="nonblock nontext museBGSize mse_pre_init" id="u25408" href="https://recriajogos.wordpress.com/"><!-- simple frame --></a>
   </div>
   <div class="clearfix grpelem" id="ppu10370"><!-- column -->
    <div class="clearfix colelem" id="pu10370"><!-- group -->
     <img class="grpelem" id="u10370" alt="" width="546" height="701" src="images/caderno-u10370.png"/><!-- rasterized frame -->
     <form class="form-grp clearfix grpelem" id="widgetu10475" method="post" enctype="multipart/form-data" action="cadastraUsuario.php"><!-- none box -->
      <div class=" clearfix grpelem" id="widgetu10477" data-required="true"><!-- none box -->
       <label class="fld-label grpelem" id="u10480" alt="&nbsp;Nome:" src="images/blank.gif" for="widgetu10477_input"><!-- state-based BG images --></label>
       <span class="fld-input NoWrap actAsDiv rounded-corners clearfix grpelem" id="u10478-4"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu10477_input" name="HTML_nome_USUARIO" tabindex="1" required/></span>
      </div>
      <div class=" clearfix grpelem" id="widgetu10484" data-required="true" data-type="email"><!-- none box -->
       <label class="fld-label grpelem" id="u10487" alt="&nbsp;Email:" src="images/blank.gif" for="widgetu10484_input"><!-- state-based BG images --></label>
       <span class="fld-input NoWrap actAsDiv rounded-corners clearfix grpelem" id="u10486-4"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu10484_input" name="HTML_email_USUARIO" tabindex="3" required/></span>
      </div>

      <img class="grpelem" id="u10482" alt="Formulário recebido." src="images/blank.gif"/><!-- state-based BG images -->
      <input class="submit-btn NoWrap grpelem" id="u10476-17" type="submit" value="" tabindex="5"/><!-- state-based BG images -->
      <div class="clearfix grpelem" id="widgetu10534" data-required="true"><!-- none box -->
       <label class="fld-label grpelem" id="u10536" alt="&nbsp;Senha:" src="images/blank.gif" for="widgetu10534_input"><!-- state-based BG images --></label>
       <span class="fld-input NoWrap actAsDiv rounded-corners clearfix grpelem" id="u10537-4"><!-- content --><input class="wrapped-input" type="password" id="widgetu10534_input" name="HTML_senha_USUARIO" tabindex="4" required/></span>
      </div>
      <div class=" clearfix grpelem" id="widgetu18815" data-required="true"><!-- none box -->
       <label class="fld-label grpelem" id="u18817" alt="&nbsp;Sobrenome (completo):" src="images/blank.gif" for="widgetu18815_input"><!-- state-based BG images --></label>
       <span class="fld-input NoWrap actAsDiv rounded-corners clearfix grpelem" id="u18816-4"><!-- content --><input class="wrapped-input" type="text" id="widgetu18815_input" name="HTML_sobrenome_USUARIO" tabindex="2" required/></span>
      </div>
     </form>
     <img class="grpelem" id="u10368" alt="" width="201" height="251" src="images/5-u10368.png"/><!-- rasterized frame -->
     <div class="grpelem" id="u10398" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-0.0698,M12=-0.9976,M21=0.9976,M22=-0.0698,SizingMethod='auto expand')" data-mu-ie-matrix-dx="268" data-mu-ie-matrix-dy="-293"><!-- rasterized frame -->
      <img id="u10398_img" alt="" width="671" height="89" src="images/pencil-23648_960_720-u10398.png"/>
     </div>
     <div class="grpelem" id="u11411-4" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.8829,M12=0.4695,M21=-0.4695,M22=0.8829,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-4" data-mu-ie-matrix-dy="-39"><!-- rasterized frame -->
      <img id="u11411-4_img" alt="Cadastro" width="179" height="60" src="images/u11411-4.png"/>
     </div>
    </div>
    <div class="clip_frame colelem" id="u9711"><!-- image -->
     <img class="block" id="u9711_img" src="images/folha%20com%20corte.png" alt="" width="71" height="34"/>
    </div>
   </div>
   <div class="clearfix grpelem" id="ppu18940-4"><!-- column -->
    <div class="clearfix colelem" id="pu18940-4"><!-- group -->
     <a class="nonblock nontext MuseLinkActive grpelem" id="u18940-4" href="formcadastrar.php"><!-- rasterized frame --><img id="u18940-4_img" alt="Cadastrar" width="98" height="26" src="images/u18940-4-a.png"/></a>
     <div class="clip_frame grpelem" id="u18941"><!-- image -->
      <img class="block" id="u18941_img" src="images/folha%20com%20corte.png" alt="" width="48" height="23"/>
     </div>
    </div>
    <div class="colelem" id="u10374" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.2419,M12=-0.9703,M21=0.9703,M22=0.2419,SizingMethod='auto expand')" data-mu-ie-matrix-dx="33" data-mu-ie-matrix-dy="-66"><!-- rasterized frame -->
     <img id="u10374_img" alt="" width="210" height="95" src="images/p993518-u10374.png"/>
    </div>
   </div>
   <a class="nonblock nontext mse_pre_init" id="u25189" href="help/index.php" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9925,M12=0.1219,M21=-0.1219,M22=0.9925,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-8" data-mu-ie-matrix-dy="-8"><!-- rasterized frame --><img id="u25189_img" alt="" width="107" height="113" src="images/brushe-balao-de-fala-pfs-u25189.png"/></a>
   <a class="nonblock nontext grpelem" id="u18939-4" href="formlogin.php"><!-- rasterized frame --><img id="u18939-4_img" alt="Entrar" width="60" height="32" src="images/u18939-4.png"/></a>
   <div class="clearfix grpelem" id="pu25187"><!-- group -->
    <img class="mse_pre_init" id="u25187" alt="" width="35" height="24" src="images/folha%20com%20corte-u25187.png"/><!-- rasterized frame -->
    <div class="shadow rounded-corners mse_pre_init" id="u25191"><!-- simple frame --></div>
    <a class="nonblock nontext mse_pre_init" id="u25192" href="help/index.php"><!-- rasterized frame --><img id="u25192_img" alt="" width="164" height="149" src="images/le%c3%a3o%20final-u25192.png"/></a>
   </div>
   <div class="verticalspacer"></div>
   <div class="mse_pre_init" id="u9715" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9986,M12=0.0523,M21=-0.0523,M22=0.9986,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-22" data-mu-ie-matrix-dy="-38"><!-- rasterized frame -->
    <img id="u9715_img" alt="" width="1459" height="869" src="images/paper10-u9715.png"/>
   </div>
  </div>
  <div class="preload_images">
   <img class="preload" src="images/u24908-a.png" alt=""/>
   <img class="preload" src="images/u18876-a.png" alt=""/>
   <img class="preload" src="images/u18870-a.png" alt=""/>
   <img class="preload" src="images/paper10.png" alt=""/>
   <img class="preload" src="images/u18833-a.png" alt=""/>
   <img class="preload" src="images/paper102.png" alt=""/>
   <img class="preload" src="images/u24142-a.png" alt=""/>
   <img class="preload" src="images/u18854-a.png" alt=""/>
   <img class="preload" src="images/u24920-a.png" alt=""/>
   <img class="preload" src="images/u18924-a.png" alt=""/>
   <img class="preload" src="images/u18896-a.png" alt=""/>
   <img class="preload" src="images/u18928-a.png" alt=""/>
   <img class="preload" src="images/u24210-a.png" alt=""/>
   <img class="preload" src="images/u18906-a.png" alt=""/>
   <img class="preload" src="images/u10480-ferr.png" alt=""/>
   <img class="preload" src="images/u10487-ferr.png" alt=""/>
   <img class="preload" src="images/u10482-fss.png" alt=""/>
   <img class="preload" src="images/u10476-17-r.png" alt=""/>
   <img class="preload" src="images/u10476-17-m.png" alt=""/>
   <img class="preload" src="images/u10476-17-fs.png" alt=""/>
   <img class="preload" src="images/u10536-ferr.png" alt=""/>
   <img class="preload" src="images/u18817-ferr.png" alt=""/>
  </div>
  <!-- JS includes -->
  <script type="text/javascript">
   if (document.location.protocol != 'https:') document.write('\x3Cscript src="http://musecdn.businesscatalyst.com/scripts/4.0/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script type="text/javascript">
   window.jQuery || document.write('\x3Cscript src="scripts/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script src="scripts/museutils.js?183364071" type="text/javascript"></script>
  <script src="scripts/jquery.musepolyfill.bgsize.js?4004268962" type="text/javascript"></script>
  <script src="scripts/jquery.scrolleffects.js?3860644955" type="text/javascript"></script>
  <script src="scripts/jquery.musemenu.js?3957776250" type="text/javascript"></script>
  <script src="scripts/webpro.js?3803554875" type="text/javascript"></script>
  <script src="scripts/jquery.watch.js?71412426" type="text/javascript"></script>
  <!-- Other scripts -->
  <script type="text/javascript">
   $(document).ready(function() { try {
(function(){var a={},b=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),16);return 0};(function(){$('link[type="text/css"]').each(function(){var b=($(this).attr("href")||"").match(/\/?css\/([\w\-]+\.css)\?(\d+)/);b&&b[1]&&b[2]&&(a[b[1]]=b[2])})})();(function(){$("body").append('<div class="version" style="display:none; width:1px; height:1px;"></div>');
for(var c=$(".version"),d=0;d<Muse.assets.required.length;){var f=Muse.assets.required[d],g=f.match(/([\w\-\.]+)\.(\w+)$/),k=g&&g[1]?g[1]:null,g=g&&g[2]?g[2]:null;switch(g.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");c.addClass(k);var g=b(c.css("color")),h=b(c.css("background-color"));g!=0||h!=0?(Muse.assets.required.splice(d,1),"undefined"!=typeof a[f]&&(g!=a[f]>>>24||h!=(a[f]&16777215))&&Muse.assets.outOfDate.push(f)):d++;c.removeClass(k);break;case "js":k.match(/^jquery-[\d\.]+/gi)&&
typeof $!="undefined"?Muse.assets.required.splice(d,1):d++;break;default:throw Error("Unsupported file type: "+g);}}c.remove();if(Muse.assets.outOfDate.length||Muse.assets.required.length)c="Alguns arquivos no servidor podem estar ausentes ou incorretos. Limpe o cache do navegador e tente novamente. Se o problema persistir, entre em contato com o autor do site.",(d=location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi))&&Muse.assets.outOfDate.length&&(c+="\nOut of date: "+Muse.assets.outOfDate.join(",")),d&&Muse.assets.required.length&&(c+="\nMissing: "+Muse.assets.required.join(",")),alert(c)})()})();
/* body */
Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
Muse.Utils.prepHyperlinks(true);/* body */
$('#u18819').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,48.38]},{"speed":[0,0],"in":[48.38,Infinity]}]);/* scroll effect */
$('#u18878').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,35.38]},{"speed":[0,0],"in":[35.38,Infinity]}]);/* scroll effect */
$('#u18878').registerOpacityScrollEffect([{"in":[-Infinity,35.38],"fade":0,"opacity":100},{"opacity":100,"in":[35.38,35.38]},{"in":[35.38,Infinity],"fade":2,"opacity":0}]);/* scroll effect */
$('#u18880').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,38.38]},{"speed":[0,0],"in":[38.38,Infinity]}]);/* scroll effect */
$('#u18880').registerOpacityScrollEffect([{"in":[-Infinity,38.38],"fade":2,"opacity":0},{"opacity":100,"in":[38.38,38.38]},{"in":[38.38,Infinity],"fade":0,"opacity":100}]);/* scroll effect */
Muse.Utils.initWidget('.MenuBar', function(elem) { return $(elem).museMenu(); });/* unifiedNavBar */
$('#menuu18821').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,34.38]},{"speed":[0,0],"in":[34.38,Infinity]}]);/* scroll effect */
$('#menuu18821').registerOpacityScrollEffect([{"in":[-Infinity,34.38],"fade":0.05,"opacity":100},{"opacity":100,"in":[34.38,34.38]},{"in":[34.38,Infinity],"fade":1,"opacity":0}]);/* scroll effect */
$('#menuu18882').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,53.38]},{"speed":[0,0],"in":[53.38,Infinity]}]);/* scroll effect */
$('#menuu18882').registerOpacityScrollEffect([{"in":[-Infinity,53.38],"fade":20,"opacity":0},{"opacity":100,"in":[53.38,53.38]},{"in":[53.38,Infinity],"fade":0,"opacity":100}]);/* scroll effect */
$('#u25404').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
$('#u25405').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
$('#u25406').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
$('#u25407').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
$('#u25408').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
Muse.Utils.initWidget('#widgetu10475', function(elem) { new WebPro.Widget.Form(elem, {validationEvent:'submit',errorStateSensitivity:'high',fieldWrapperClass:'fld-grp',formSubmittedClass:'frm-sub-st',formErrorClass:'frm-subm-err-st',formDeliveredClass:'frm-subm-ok-st',notEmptyClass:'non-empty-st',focusClass:'focus-st',invalidClass:'fld-err-st',requiredClass:'fld-err-st',ajaxSubmit:true}); });/* #widgetu10475 */
$('#u25189').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-228]},{"speed":[0,0],"in":[-228,Infinity]}]);/* scroll effect */
$('#u25187').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-232]},{"speed":[0,0],"in":[-232,Infinity]}]);/* scroll effect */
$('#u25191').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-230]},{"speed":[0,0],"in":[-230,Infinity]}]);/* scroll effect */
$('#u25192').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-227]},{"speed":[0,0],"in":[-227,Infinity]}]);/* scroll effect */
$('#u9715').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,1401.02]},{"speed":[0,0],"in":[1401.02,Infinity]}]);/* scroll effect */
Muse.Utils.fullPage('#page');/* 100% height page */
Muse.Utils.showWidgetsWhenReady();/* body */
Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
} catch(e) { if (e && 'function' == typeof e.notify) e.notify(); else Muse.Assert.fail('Error calling selector function:' + e); }});
</script>
   </body>
</html>
