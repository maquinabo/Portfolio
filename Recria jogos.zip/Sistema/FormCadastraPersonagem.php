

<center> CADASTRO JOGOS </center>

<form method="POST" name="FormCadastraPersonagem" action="cadastraPersonagem.php">
    <table width="80%" align="center">
        
        <tr>
               <td> Titulo:</td>
               <td> <input type="text" name="HTML_titulo_PERSONAGEM" maxlength="11" ></td>
        </tr>
        
        <tr>
            <td> Descrição: </td>
              <td><input type="text" name="HTML_curiosidade_PERSONAGEM" maxlength="150" size="100" ></td>
        </tr>  
        
        <tr>
            <td > Objetivo (Pais):</td>
               <td> <input type="text" name="HTML_significado_PERSONAGEM" size="100"></td>
        </tr>  
        <td><input type="submit"></td>
        
    </table>
</form>    
        