<?php session_start(); ?>
<!DOCTYPE html>
<html class="html" lang="pt-BR">
 <head>

  <script type="text/javascript">
   if(typeof Muse == "undefined") window.Muse = {}; window.Muse.assets = {"required":["jquery-1.8.3.min.js", "museutils.js", "jquery.musepolyfill.bgsize.js", "jquery.musemenu.js", "jquery.scrolleffects.js", "jquery.watch.js", "webpro.js", "formcadastranovidades.css"], "outOfDate":[]};
</script>
  
  <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
  <link rel="shortcut icon" href="images/favicon.ico"/>
  <meta name="generator" content="2015.0.0.309"/>
  <title>Cadastrar Novidades</title>
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="css/site_global.css?4052507572"/>
  <link rel="stylesheet" type="text/css" href="css/formcadastranovidades.css" id="pagesheet"/>
  <!-- Other scripts -->
  <script type="text/javascript">
   document.documentElement.className += ' js';
</script>
  <!-- JS includes -->
  <!--[if lt IE 9]>
  <script src="scripts/html5shiv.js?4241844378" type="text/javascript"></script>
  <![endif]-->
   </head>
 <body class="museBGSize">

  <div class="clearfix" id="page"><!-- group -->
   <div class="clearfix grpelem" id="pu8875"><!-- group -->
    <div class="grpelem" id="u8875" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.0349,M12=-0.9994,M21=0.9994,M22=0.0349,SizingMethod='auto expand')" data-mu-ie-matrix-dx="211" data-mu-ie-matrix-dy="-235"><!-- rasterized frame -->
     <img id="u8875_img" alt="" width="913" height="459" src="images/paper10-u8875.png"/>
    </div>
    <nav class="MenuBar clearfix grpelem" id="menuu8880"><!-- vertical box -->
     <div class="MenuItemContainer clearfix colelem" id="u8916"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u8919" href="index.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u8922" alt="Início" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u12010"><!-- horizontal box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u12011" href="usuarios.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u12013" alt="Usuários" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u8881"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u8882" href="novidades.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u8884" alt="Novidades" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u11021"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u11022" href="jogos.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u11024" alt="Jogos " src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u11370"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u11373" href="personagens.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u11376" alt="Personagens" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u10866"><!-- horizontal box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u10867" href="sobre-nos.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u10869" alt="Sobre Nós" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u11093"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u11096" href="compras.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u11097" alt="Compras" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
    </nav>
    <div class="clip_frame grpelem" id="u8873"><!-- image -->
     <img class="block" id="u8873_img" src="images/logo%20mais%20novo%20que%20tudo23.png" alt="" width="216" height="203"/>
     <STYLE type="text/css">
<!--
a:link {text-decoration: none;color: black}
a:active {text-decoration: none;}
a:visited {text-decoration: none;color: black}
a:hover {text-decoration: none;color: black}
</STYLE>
    <div id="mi1"><a href="Logoff.php" ><font face="Berlin Sans FB" size="6pt"> Sair </font> </a></div>

    </div>
    <img class="grpelem" id="u8927" alt="" width="564" height="725" src="images/caderno-u8927.png"/><!-- rasterized frame -->
    <form class="form-grp clearfix grpelem" id="widgetu9067" method="post" enctype="multipart/form-data" action="scripts/form-u9067.php"><!-- none box -->
     <div class="fld-grp clearfix grpelem" id="widgetu9068" data-required="true"><!-- none box -->
      <label class="fld-label grpelem" id="u9069" alt="&nbsp;Título:" src="images/blank.gif" for="widgetu9068_input"><!-- state-based BG images --></label>
      <span class="fld-input NoWrap actAsDiv shadow rounded-corners clearfix grpelem" id="u9070-4"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu9068_input" name="custom_U9068" tabindex="1"/><label class="wrapped-input fld-prompt" id="widgetu9068_prompt" for="widgetu9068_input"><span class="actAsPara">Inserir título</span></label></span>
     </div>
     <div class="clearfix grpelem" id="u9072-4"><!-- content -->
      <p>Enviando formulário…</p>
     </div>
     <div class="clearfix grpelem" id="u9074-4"><!-- content -->
      <p>O servidor encontrou um erro.</p>
     </div>
     <img class="grpelem" id="u9073" alt="Formulário recebido." src="images/blank.gif"/><!-- state-based BG images -->
     <input class="submit-btn NoWrap grpelem" id="u9083-17" type="submit" value="" tabindex="3"/><!-- state-based BG images -->
     <div class="fld-grp clearfix grpelem" id="widgetu9079" data-required="true"><!-- none box -->
      <label class="fld-label grpelem" id="u9081" alt="&nbsp;Conteúdo:" src="images/blank.gif" for="widgetu9079_input"><!-- state-based BG images --></label>
      <span class="fld-textarea actAsDiv shadow rounded-corners clearfix grpelem" id="u9082-4"><!-- content --><textarea class="wrapped-input" id="widgetu9079_input" name="custom_U9079" tabindex="2"></textarea><label class="wrapped-input fld-prompt" id="widgetu9079_prompt" for="widgetu9079_input"><span class="actAsPara">Insira o conteúdo</span></label></span>
     </div>
    </form>
    <div class="grpelem" id="u9084"><!-- custom html -->
     <form action="script/url/to/process" method="post">
<label> Insira a imagem: </label>
<input type="file" />
</form>
</div>
    <a class="nonblock nontext clip_frame clearfix grpelem" id="u9086" href="novidades.php" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-0.9903,M12=0.1392,M21=-0.1392,M22=-0.9903,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-1" data-mu-ie-matrix-dy="-6"><!-- image --><img class="position_content" id="u9086_img" src="images/arrow-310611_960_720%20(1)-crop-u9086.png" alt="" width="88" height="27"/></a>
   </div>
   <div class="grpelem" id="u8923" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.0698,M12=-0.9976,M21=0.9976,M22=0.0698,SizingMethod='auto expand')" data-mu-ie-matrix-dx="281" data-mu-ie-matrix-dy="-307"><!-- rasterized frame -->
    <img id="u8923_img" alt="" width="681" height="71" src="images/pencil-23648_960_720-u8923.png"/>
   </div>
   <div class="clearfix grpelem" id="ppu8877"><!-- column -->
    <div class="clearfix colelem" id="pu8877"><!-- group -->
     <img class="grpelem" id="u8877" alt="" width="211" height="193" src="images/bagulho1-u8877.png"/><!-- rasterized frame -->
     <div class="grpelem" id="u8879-5" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9816,M12=0.1908,M21=-0.1908,M22=0.9816,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-3" data-mu-ie-matrix-dy="-17"><!-- rasterized frame -->
      <img id="u8879-5_img" alt="&nbsp;Novidades" width="179" height="45" src="images/u8879-5.png"/>
     </div>
    </div>
    <div class="colelem" id="u8931" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.2419,M12=-0.9703,M21=0.9703,M22=0.2419,SizingMethod='auto expand')" data-mu-ie-matrix-dx="33" data-mu-ie-matrix-dy="-66"><!-- rasterized frame -->
     <img id="u8931_img" alt="" width="211" height="96" src="images/p993518-u8931.png"/>
    </div>
   </div>
   <div class="verticalspacer"></div>
   <div class="mse_pre_init" id="u8929" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9986,M12=0.0523,M21=-0.0523,M22=0.9986,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-7" data-mu-ie-matrix-dy="-36"><!-- rasterized frame -->
    <img id="u8929_img" alt="" width="1376" height="313" src="images/paper10-u8929.png"/>
   </div>
  </div>
  <div class="preload_images">
   <img class="preload" src="images/u8922-a.png" alt=""/>
   <img class="preload" src="images/u12013-a.png" alt=""/>
   <img class="preload" src="images/u8884-a.png" alt=""/>
   <img class="preload" src="images/u11024-a.png" alt=""/>
   <img class="preload" src="images/u11376-a.png" alt=""/>
   <img class="preload" src="images/u10869-a.png" alt=""/>
   <img class="preload" src="images/u11097-a.png" alt=""/>
   <img class="preload" src="images/u9069-ferr.png" alt=""/>
   <img class="preload" src="images/u9073-fss.png" alt=""/>
   <img class="preload" src="images/u9083-17-r.png" alt=""/>
   <img class="preload" src="images/u9083-17-m.png" alt=""/>
   <img class="preload" src="images/u9083-17-fs.png" alt=""/>
   <img class="preload" src="images/u9081-ferr.png" alt=""/>
  </div>
  <!-- JS includes -->
  <script type="text/javascript">
   if (document.location.protocol != 'https:') document.write('\x3Cscript src="http://musecdn.businesscatalyst.com/scripts/4.0/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script type="text/javascript">
   window.jQuery || document.write('\x3Cscript src="scripts/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script src="scripts/museutils.js?183364071" type="text/javascript"></script>
  <script src="scripts/jquery.musepolyfill.bgsize.js?4004268962" type="text/javascript"></script>
  <script src="scripts/jquery.musemenu.js?3957776250" type="text/javascript"></script>
  <script src="scripts/webpro.js?3803554875" type="text/javascript"></script>
  <script src="scripts/jquery.scrolleffects.js?3860644955" type="text/javascript"></script>
  <script src="scripts/jquery.watch.js?71412426" type="text/javascript"></script>
  <!-- Other scripts -->
  <script type="text/javascript">
   $(document).ready(function() { try {
(function(){var a={},b=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),16);return 0};(function(){$('link[type="text/css"]').each(function(){var b=($(this).attr("href")||"").match(/\/?css\/([\w\-]+\.css)\?(\d+)/);b&&b[1]&&b[2]&&(a[b[1]]=b[2])})})();(function(){$("body").append('<div class="version" style="display:none; width:1px; height:1px;"></div>');
for(var c=$(".version"),d=0;d<Muse.assets.required.length;){var f=Muse.assets.required[d],g=f.match(/([\w\-\.]+)\.(\w+)$/),k=g&&g[1]?g[1]:null,g=g&&g[2]?g[2]:null;switch(g.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");c.addClass(k);var g=b(c.css("color")),h=b(c.css("background-color"));g!=0||h!=0?(Muse.assets.required.splice(d,1),"undefined"!=typeof a[f]&&(g!=a[f]>>>24||h!=(a[f]&16777215))&&Muse.assets.outOfDate.push(f)):d++;c.removeClass(k);break;case "js":k.match(/^jquery-[\d\.]+/gi)&&
typeof $!="undefined"?Muse.assets.required.splice(d,1):d++;break;default:throw Error("Unsupported file type: "+g);}}c.remove();if(Muse.assets.outOfDate.length||Muse.assets.required.length)c="Alguns arquivos no servidor podem estar ausentes ou incorretos. Limpe o cache do navegador e tente novamente. Se o problema persistir, entre em contato com o autor do site.",(d=location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi))&&Muse.assets.outOfDate.length&&(c+="\nOut of date: "+Muse.assets.outOfDate.join(",")),d&&Muse.assets.required.length&&(c+="\nMissing: "+Muse.assets.required.join(",")),alert(c)})()})();
/* body */
Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
Muse.Utils.prepHyperlinks(true);/* body */
Muse.Utils.initWidget('.MenuBar', function(elem) { return $(elem).museMenu(); });/* unifiedNavBar */
Muse.Utils.initWidget('#widgetu9067', function(elem) { new WebPro.Widget.Form(elem, {validationEvent:'submit',errorStateSensitivity:'high',fieldWrapperClass:'fld-grp',formSubmittedClass:'frm-sub-st',formErrorClass:'frm-subm-err-st',formDeliveredClass:'frm-subm-ok-st',notEmptyClass:'non-empty-st',focusClass:'focus-st',invalidClass:'fld-err-st',requiredClass:'fld-err-st',ajaxSubmit:true}); });/* #widgetu9067 */
$('#u8929').registerPositionScrollEffect([{"in":[-Infinity,1354.43],"speed":[0,1]},{"in":[1354.43,Infinity],"speed":[0,0]}]);/* scroll effect */
Muse.Utils.fullPage('#page');/* 100% height page */
Muse.Utils.showWidgetsWhenReady();/* body */
Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
} catch(e) { if (e && 'function' == typeof e.notify) e.notify(); else Muse.Assert.fail('Error calling selector function:' + e); }});
</script>
   </body>
</html>
