<!DOCTYPE html>
<html class="html" lang="pt-BR">
 <head>

  <script type="text/javascript">
   if(typeof Muse == "undefined") window.Muse = {}; window.Muse.assets = {"required":["jquery-1.8.3.min.js", "museutils.js", "jquery.musepolyfill.bgsize.js", "jquery.watch.js", "jquery.musemenu.js", "jquery.scrolleffects.js", "compras.css"], "outOfDate":[]};
</script>
  
  <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
   <link rel="shortcut icon" href="images/favicon.ico"/>
  <meta name="generator" content="2015.0.0.309"/>
  <title>Compras</title>
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="css/site_global.css?4052507572"/>
  <link rel="stylesheet" type="text/css" href="css/compras.css" id="pagesheet"/>
  <!-- Other scripts -->
  <script type="text/javascript">
   document.documentElement.className += ' js';
</script>
  <!-- JS includes -->
  <!--[if lt IE 9]>
  <script src="scripts/html5shiv.js?4241844378" type="text/javascript"></script>
  <![endif]-->
   </head>
 <body class="museBGSize">

  <div class="clearfix" id="page"><!-- group -->
   <div class="clearfix grpelem" id="pu10376"><!-- group -->
    <div class="grpelem" id="u10376" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.0349,M12=-0.9994,M21=0.9994,M22=0.0349,SizingMethod='auto expand')" data-mu-ie-matrix-dx="211" data-mu-ie-matrix-dy="-235"><!-- rasterized frame -->
     <img id="u10376_img" alt="" width="913" height="459" src="images/paper10-u10376.png"/>
    </div>
    <nav class="MenuBar clearfix grpelem" id="menuu10332"><!-- vertical box -->
     <div class="MenuItemContainer clearfix colelem" id="u10347"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u10348" href="index.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u10351" alt="Início" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u12031"><!-- horizontal box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u12032" href="usuarios.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u12035" alt="Usuários" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u10361"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u10364" href="novidades.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u10365" alt="Novidades" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u11070"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u11073" href="jogos.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u11074" alt="Jogos " src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u11356"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u11357" href="personagens.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u11358" alt="Personagens" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u10915"><!-- horizontal box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u10918" href="sobre-nos.php"><!-- horizontal box --><img class="MenuItemLabel grpelem" id="u10919" alt="Sobre Nós" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix colelem" id="u11142"><!-- horizontal box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu MuseMenuActive clearfix grpelem" id="u11145" href="compras.php"><!-- horizontal box --><div class="MenuItemLabel grpelem" id="u11146-4"><!-- rasterized frame --><div id="u11146-4_clip"><img id="u11146-4_img" alt="Compras" width="160" height="33" src="images/u11146-4-a.png"/></div></div></a>
     </div>
    </nav>
    <div class="clip_frame grpelem" id="u10380"><!-- image -->
     <img class="block" id="u10380_img" src="images/logo%20mais%20novo%20que%20tudo23.png" alt="" width="216" height="203"/>
     <STYLE type="text/css">
<!--
a:link {text-decoration: none;color: black}
a:active {text-decoration: none;}
a:visited {text-decoration: none;color: black}
a:hover {text-decoration: none;color: black}
</STYLE>
    <div id="mi1"><a href="Logoff.php" ><font face="Berlin Sans FB" size="6pt"> Sair </font> </a></div>

    </div>
    <img class="grpelem" id="u10374" alt="" width="564" height="725" src="images/caderno-u10374.png"/><!-- rasterized frame -->
   </div>
   <div class="grpelem" id="u10378" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.0698,M12=-0.9976,M21=0.9976,M22=0.0698,SizingMethod='auto expand')" data-mu-ie-matrix-dx="278" data-mu-ie-matrix-dy="-304"><!-- rasterized frame -->
    <img id="u10378_img" alt="" width="681" height="77" src="images/pencil-23648_960_720-u10378.png"/>
   </div>
   <div class="clearfix grpelem" id="ppu10735"><!-- column -->
    <div class="clearfix colelem" id="pu10735"><!-- group -->
     <div class="grpelem" id="u10735" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9976,M12=0.0698,M21=-0.0698,M22=0.9976,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-7" data-mu-ie-matrix-dy="-6"><!-- rasterized frame -->
      <img id="u10735_img" alt="" width="187" height="196" src="images/bagulho2-u10735.png"/>
     </div>
     <div class="grpelem" id="u10331-4" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9816,M12=-0.1908,M21=0.1908,M22=0.9816,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-3" data-mu-ie-matrix-dy="-17"><!-- rasterized frame -->
      <img id="u10331-4_img" alt="Compras" width="179" height="45" src="images/u10331-4.png"/>
     </div>
    </div>
    <div class="colelem" id="u10382" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.2419,M12=-0.9703,M21=0.9703,M22=0.2419,SizingMethod='auto expand')" data-mu-ie-matrix-dx="33" data-mu-ie-matrix-dy="-66"><!-- rasterized frame -->
     <img id="u10382_img" alt="" width="211" height="96" src="images/p993518-u10382.png"/>
    </div>
   </div>
   <div class="clearfix grpelem" id="u10330-3"><!-- content -->
    <p>&nbsp;</p>
   </div>
   <div class="verticalspacer"></div>
   <div class="mse_pre_init" id="u10372" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9986,M12=0.0523,M21=-0.0523,M22=0.9986,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-7" data-mu-ie-matrix-dy="-36"><!-- rasterized frame -->
    <img id="u10372_img" alt="" width="1376" height="313" src="images/paper10-u10372.png"/>
   </div>
  </div>
  <div class="preload_images">
   <img class="preload" src="images/u10351-a.png" alt=""/>
   <img class="preload" src="images/u12035-a.png" alt=""/>
   <img class="preload" src="images/u10365-a.png" alt=""/>
   <img class="preload" src="images/u11074-a.png" alt=""/>
   <img class="preload" src="images/u11358-a.png" alt=""/>
   <img class="preload" src="images/u10919-a.png" alt=""/>
  </div>
  <!-- JS includes -->
  <script type="text/javascript">
   if (document.location.protocol != 'https:') document.write('\x3Cscript src="http://musecdn.businesscatalyst.com/scripts/4.0/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script type="text/javascript">
   window.jQuery || document.write('\x3Cscript src="scripts/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script src="scripts/museutils.js?183364071" type="text/javascript"></script>
  <script src="scripts/jquery.musepolyfill.bgsize.js?4004268962" type="text/javascript"></script>
  <script src="scripts/jquery.musemenu.js?3957776250" type="text/javascript"></script>
  <script src="scripts/jquery.scrolleffects.js?3860644955" type="text/javascript"></script>
  <script src="scripts/jquery.watch.js?71412426" type="text/javascript"></script>
  <!-- Other scripts -->
  <script type="text/javascript">
   $(document).ready(function() { try {
(function(){var a={},b=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),16);return 0};(function(){$('link[type="text/css"]').each(function(){var b=($(this).attr("href")||"").match(/\/?css\/([\w\-]+\.css)\?(\d+)/);b&&b[1]&&b[2]&&(a[b[1]]=b[2])})})();(function(){$("body").append('<div class="version" style="display:none; width:1px; height:1px;"></div>');
for(var c=$(".version"),d=0;d<Muse.assets.required.length;){var f=Muse.assets.required[d],g=f.match(/([\w\-\.]+)\.(\w+)$/),k=g&&g[1]?g[1]:null,g=g&&g[2]?g[2]:null;switch(g.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");c.addClass(k);var g=b(c.css("color")),h=b(c.css("background-color"));g!=0||h!=0?(Muse.assets.required.splice(d,1),"undefined"!=typeof a[f]&&(g!=a[f]>>>24||h!=(a[f]&16777215))&&Muse.assets.outOfDate.push(f)):d++;c.removeClass(k);break;case "js":k.match(/^jquery-[\d\.]+/gi)&&
typeof $!="undefined"?Muse.assets.required.splice(d,1):d++;break;default:throw Error("Unsupported file type: "+g);}}c.remove();if(Muse.assets.outOfDate.length||Muse.assets.required.length)c="Alguns arquivos no servidor podem estar ausentes ou incorretos. Limpe o cache do navegador e tente novamente. Se o problema persistir, entre em contato com o autor do site.",(d=location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi))&&Muse.assets.outOfDate.length&&(c+="\nOut of date: "+Muse.assets.outOfDate.join(",")),d&&Muse.assets.required.length&&(c+="\nMissing: "+Muse.assets.required.join(",")),alert(c)})()})();
/* body */
Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
Muse.Utils.prepHyperlinks(true);/* body */
Muse.Utils.initWidget('.MenuBar', function(elem) { return $(elem).museMenu(); });/* unifiedNavBar */
$('#u10372').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,1354.43]},{"speed":[0,0],"in":[1354.43,Infinity]}]);/* scroll effect */
Muse.Utils.fullPage('#page');/* 100% height page */
Muse.Utils.showWidgetsWhenReady();/* body */
Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
} catch(e) { if (e && 'function' == typeof e.notify) e.notify(); else Muse.Assert.fail('Error calling selector function:' + e); }});
</script>
   </body>
</html>
