<?php session_start();
?>
<!DOCTYPE html>
<html class="html" lang="pt-BR">
 <head>

  <script type="text/javascript">
   if(typeof Muse == "undefined") window.Muse = {}; window.Muse.assets = {"required":["jquery-1.8.3.min.js", "museutils.js", "jquery.musepolyfill.bgsize.js", "jquery.scrolleffects.js", "jquery.musemenu.js", "webpro.js", "jquery.watch.js", "formcadastracrianca.css"], "outOfDate":[]};
</script>
  
  <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
    <link rel="shortcut icon" href="images/in%c3%adcio-favicon.ico?3913429556"/>
  <meta name="generator" content="2015.0.0.309"/>
  <title>Cadastrar</title>
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="css/site_global.css?4052507572"/>
  <link rel="stylesheet" type="text/css" href="css/formcadastracrianca.css?3864873701" id="pagesheet"/>
  <!-- Other scripts -->
  <script type="text/javascript">
   document.documentElement.className += ' js';
</script>
  <!-- JS includes -->
  <!--[if lt IE 9]>
  <script src="scripts/html5shiv.js?4241844378" type="text/javascript"></script>
  <![endif]-->
   </head>
 <body class="museBGSize">

  <div class="clearfix" id="page"><!-- group -->
   <div class="clearfix grpelem" id="ppu19431"><!-- column -->
    <div class="clearfix colelem" id="pu19431"><!-- group -->
     <div class="mse_pre_init" id="u19431" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-1,M12=0,M21=0,M22=-1,SizingMethod='auto expand')" data-mu-ie-matrix-dx="0" data-mu-ie-matrix-dy="0"><!-- rasterized frame -->
      <img id="u19431_img" alt="" width="1200" height="619" src="images/papernovo-u19431.png"/>
     </div>
     <img class="mse_pre_init ose_pre_init" id="u19464" alt="" width="222" height="197" src="images/logo%20mais%20novo%20que%20tudo23-u19464.png"/><!-- rasterized frame -->
     <img class="mse_pre_init ose_pre_init" id="u19429" alt="" width="155" height="139" src="images/logo%20mais%20novo%20que%20tudo23-u19429.png"/><!-- rasterized frame -->
    </div>
    <nav class="MenuBar clearfix ose_pre_init mse_pre_init" id="menuu19372"><!-- horizontal box -->
     <div class="MenuItemContainer clearfix grpelem" id="u19401"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19404" href="index.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19405" alt="Início" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19422"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19423" href="novidades.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19425" alt="Novidades" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19408"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19418" href="jogos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19419" alt="Jogos" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u19420"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u19409"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u19410"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u19411"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u19414" href="sobre-os-jogos.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u19417-4"><!-- rasterized frame --><div id="u19417-4_clip"><img id="u19417-4_img" alt="Sobre os Jogos" width="156" height="33" src="images/u19417-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19373"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19374" href="personagens.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19376" alt="Personagens" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u19377"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u19378"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u19379"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u19380"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u19381" href="sobre-os-personagens.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u19383-4"><!-- rasterized frame --><div id="u19383-4_clip"><img id="u19383-4_img" alt="Sobre os Personagens" width="214" height="31" src="images/u19383-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19394"><!-- vertical box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19397" href="sobre-nos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19398" alt="Sobre Nós" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19387"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19388" href="gerenciar.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19390" alt="Gerenciar" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
    </nav>
    <nav class="MenuBar clearfix ose_pre_init mse_pre_init" id="menuu19473"><!-- horizontal box -->
     <div class="MenuItemContainer clearfix grpelem" id="u19495"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19496" href="index.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19497" alt="Início" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19509"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19512" href="novidades.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19513" alt="Novidades" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19516"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19517" href="jogos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19518" alt="Jogos" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u19519"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u19521"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u19522"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u19523"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u19524" href="sobre-os-jogos.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u19525-4"><!-- rasterized frame --><div id="u19525-4_clip"><img id="u19525-4_img" alt="Sobre os Jogos" width="145" height="31" src="images/u19525-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19481"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19482" href="personagens.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19483" alt="Personagens" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u19485"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u19486"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u19487"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u19488"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u19491" href="sobre-os-personagens.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u19492-4"><!-- rasterized frame --><div id="u19492-4_clip"><img id="u19492-4_img" alt="Sobre os Personagens" width="214" height="31" src="images/u19492-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19502"><!-- vertical box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19505" href="sobre-nos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19507" alt="Sobre Nós" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19474"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19475" href="gerenciar.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19477" alt="Gerenciar" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
    </nav>
    <div class="mse_pre_init" id="u19670"><!-- simple frame --></div>
    <a class="nonblock nontext rounded-corners mse_pre_init" id="u19671" href="https://www.facebook.com/recriajogos"><!-- simple frame --></a>
    <a class="nonblock nontext museBGSize mse_pre_init" id="u19672" href="https://twitter.com/recriajogos"><!-- simple frame --></a>
    <a class="nonblock nontext museBGSize mse_pre_init" id="u19673" href="https://www.youtube.com/channel/UCy1YqCHq2qD1-eH30qrFOlA"><!-- simple frame --></a>
    <a class="nonblock nontext museBGSize mse_pre_init" id="u19674" href="https://recriajogos.wordpress.com/"><!-- simple frame --></a>
   </div>
   <div class="clearfix grpelem" id="ppu19550"><!-- column -->
    <div class="clearfix colelem" id="pu19550"><!-- group -->
     <img class="grpelem" id="u19550" alt="" width="546" height="599" src="images/bloco-de-notas_2252413-u19550.png"/><!-- rasterized frame -->
     <form class="form-grp clearfix grpelem" id="widgetu19435" method="post" enctype="multipart/form-data" action="cadastraCrianca.php"><!-- none box -->
      <div class=" clearfix grpelem" id="widgetu19448" data-required="true"><!-- none box -->
       <label class="fld-label grpelem" id="u19449" alt="&nbsp;Nome:" src="images/blank.gif" for="widgetu19448_input"><!-- state-based BG images --></label>
       <span class="fld-input NoWrap actAsDiv rounded-corners clearfix grpelem" id="u19451-4"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu19448_input" name="HTML_nome_SUBUSUARIO" tabindex="1" required/></span>
      </div>
      <img class="grpelem" id="u19453" alt="Formulário recebido." src="images/blank.gif"/><!-- state-based BG images -->
      <input class="submit-btn NoWrap grpelem" id="u19455-17" type="submit" value="" tabindex="3"/><!-- state-based BG images -->
      <div class=" clearfix grpelem" id="widgetu19440" data-required="true"><!-- none box -->
       <label class="fld-label grpelem" id="u19443" alt="&nbsp;Apelido:" src="images/blank.gif" for="widgetu19440_input"><!-- state-based BG images --></label>
       <span class="fld-input NoWrap actAsDiv rounded-corners clearfix grpelem" id="u19441-4"><!-- content --><input class="wrapped-input" type="text" id="widgetu19440_input" name="HTML_apelido_SUBUSUARIO" tabindex="2" required/></span>
      </div>
     </form>
     <div class="grpelem" id="u19664" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-0.0698,M12=-0.9976,M21=0.9976,M22=-0.0698,SizingMethod='auto expand')" data-mu-ie-matrix-dx="268" data-mu-ie-matrix-dy="-293"><!-- rasterized frame -->
      <img id="u19664_img" alt="" width="671" height="89" src="images/pencil-23648_960_720-u19664.png"/>
     </div>
     <img class="grpelem" id="u19469" alt="" width="201" height="251" src="images/5-u19469.png"/><!-- rasterized frame -->
     <div class="grpelem" id="u19468-4" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.8829,M12=0.4695,M21=-0.4695,M22=0.8829,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-4" data-mu-ie-matrix-dy="-39"><!-- rasterized frame -->
      <img id="u19468-4_img" alt="Cadastro" width="179" height="60" src="images/u19468-4.png"/>
     </div>
    </div>
    <div class="clip_frame colelem" id="u19433"><!-- image -->
     <img class="block" id="u19433_img" src="images/folha%20com%20corte.png" alt="" width="71" height="34"/>
    </div>
   </div>
   <div class="clearfix grpelem" id="ppu19456-4"><!-- column -->
    <div class="clearfix colelem" id="pu19456-4"><!-- group -->
        <div class="clearfix colelem" id="mi" ><!-- group -->
        <?php 
        if(isset($_SESSION['status']) && $_SESSION['status']== false) { 
       ?>
    </div>
     <a class="nonblock nontext grpelem" id="u19456-4" href="formcadastrar.php"><!-- rasterized frame --><img id="u19456-4_img" alt="Cadastrar" width="98" height="26" src="images/u19456-4.png"/></a>
     <a class="nonblock nontext grpelem" id="u19463-4" href="formlogin.php"><!-- rasterized frame --><img id="u19463-4_img" alt="Entrar" width="60" height="32" src="images/u19463-4.png"/></a>
     <div class="clip_frame grpelem" id="u19461"><!-- image -->
      <img class="block" id="u19461_img" src="images/folha%20com%20corte.png" alt="" width="48" height="23"/>
     </div>
    </div>
        <div class="clearfix colelem" id="mi" ><!-- group -->
         
        <?php 
       }else{
        if(isset($_SESSION['status'])== true)?>
         <font size="5pt" face="Berlin Sans FB"> 
             <?php  echo $_SESSION['msg']; ?>
            <?php //echo $_SESSION['descricao']?>
         </font></div>
         <STYLE type="text/css">
<!--
a:link {text-decoration: none;color: black}
a:active {text-decoration: none;}
a:visited {text-decoration: none;color: black}
a:hover {text-decoration: none;color: black}
</STYLE>
    <div class="clip_frame grpelem" id="u25781"><!-- image -->
      <img class="block" id="u2578_img" src="images/folha%20com%20corte.png" alt="" width="48" height="23"/>
     </div>
    <div id="mi1"><a href="Logoff.php" ><font face="Berlin Sans FB" size="5pt"> Sair </font> </a></div>
    
         <?php
       }
       ?>
   </div>
    <div class="colelem" id="u19667" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.2419,M12=-0.9703,M21=0.9703,M22=0.2419,SizingMethod='auto expand')" data-mu-ie-matrix-dx="33" data-mu-ie-matrix-dy="-66"><!-- rasterized frame -->
     <img id="u19667_img" alt="" width="210" height="95" src="images/p993518-u19667.png"/>
    </div>
   </div>
   <div class="clearfix grpelem" id="pu19677"><!-- group -->
    <a class="nonblock nontext mse_pre_init ose_pre_init" id="u19677" href="help/index.php" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9925,M12=0.1219,M21=-0.1219,M22=0.9925,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-8" data-mu-ie-matrix-dy="-8"><!-- rasterized frame --><img id="u19677_img" alt="" width="107" height="113" src="images/brushe-balao-de-fala-pfs-u19677.png"/></a>
    <img class="mse_pre_init ose_pre_init" id="u19675" alt="" width="35" height="24" src="images/folha%20com%20corte-u19675.png"/><!-- rasterized frame -->
    <div class="shadow rounded-corners ose_pre_init mse_pre_init" id="u19679"><!-- simple frame --></div>
   </div>
      
   <a class="nonblock nontext mse_pre_init ose_pre_init" id="u19680" href="help/index.php"><!-- rasterized frame --><img id="u19680_img" alt="" width="164" height="149" src="images/le%c3%a3o%20final-u19680.png"/></a>
   <div class="verticalspacer"></div>
   <div class="mse_pre_init" id="u19466" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9986,M12=0.0523,M21=-0.0523,M22=0.9986,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-22" data-mu-ie-matrix-dy="-38"><!-- rasterized frame -->
    <img id="u19466_img" alt="" width="1459" height="869" src="images/paper10-u19466.png"/>
   </div>
  </div>
  <div class="preload_images">
   <img class="preload" src="images/u19405-a.png" alt=""/>
   <img class="preload" src="images/u19425-a.png" alt=""/>
   <img class="preload" src="images/u19419-a.png" alt=""/>
   <img class="preload" src="images/paper10.png" alt=""/>
   <img class="preload" src="images/u19376-a.png" alt=""/>
   <img class="preload" src="images/paper102.png" alt=""/>
   <img class="preload" src="images/u19398-a.png" alt=""/>
   <img class="preload" src="images/u19390-a.png" alt=""/>
   <img class="preload" src="images/u19497-a.png" alt=""/>
   <img class="preload" src="images/u19513-a.png" alt=""/>
   <img class="preload" src="images/u19518-a.png" alt=""/>
   <img class="preload" src="images/u19483-a.png" alt=""/>
   <img class="preload" src="images/u19507-a.png" alt=""/>
   <img class="preload" src="images/u19477-a.png" alt=""/>
   <img class="preload" src="images/u19449-ferr.png" alt=""/>
   <img class="preload" src="images/u19453-fss.png" alt=""/>
   <img class="preload" src="images/u19455-17-r.png" alt=""/>
   <img class="preload" src="images/u19455-17-m.png" alt=""/>
   <img class="preload" src="images/u19455-17-fs.png" alt=""/>
   <img class="preload" src="images/u19443-ferr.png" alt=""/>
  </div>
  <!-- JS includes -->
  <script type="text/javascript">
   if (document.location.protocol != 'https:') document.write('\x3Cscript src="http://musecdn.businesscatalyst.com/scripts/4.0/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script type="text/javascript">
   window.jQuery || document.write('\x3Cscript src="scripts/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script src="scripts/museutils.js?183364071" type="text/javascript"></script>
  <script src="scripts/jquery.musepolyfill.bgsize.js?4004268962" type="text/javascript"></script>
  <script src="scripts/jquery.scrolleffects.js?3860644955" type="text/javascript"></script>
  <script src="scripts/jquery.musemenu.js?3957776250" type="text/javascript"></script>
  <script src="scripts/webpro.js?3803554875" type="text/javascript"></script>
  <script src="scripts/jquery.watch.js?71412426" type="text/javascript"></script>
  <!-- Other scripts -->
  <script type="text/javascript">
   $(document).ready(function() { try {
(function(){var a={},b=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),16);return 0};(function(){$('link[type="text/css"]').each(function(){var b=($(this).attr("href")||"").match(/\/?css\/([\w\-]+\.css)\?(\d+)/);b&&b[1]&&b[2]&&(a[b[1]]=b[2])})})();(function(){$("body").append('<div class="version" style="display:none; width:1px; height:1px;"></div>');
for(var c=$(".version"),d=0;d<Muse.assets.required.length;){var f=Muse.assets.required[d],g=f.match(/([\w\-\.]+)\.(\w+)$/),k=g&&g[1]?g[1]:null,g=g&&g[2]?g[2]:null;switch(g.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");c.addClass(k);var g=b(c.css("color")),h=b(c.css("background-color"));g!=0||h!=0?(Muse.assets.required.splice(d,1),"undefined"!=typeof a[f]&&(g!=a[f]>>>24||h!=(a[f]&16777215))&&Muse.assets.outOfDate.push(f)):d++;c.removeClass(k);break;case "js":k.match(/^jquery-[\d\.]+/gi)&&
typeof $!="undefined"?Muse.assets.required.splice(d,1):d++;break;default:throw Error("Unsupported file type: "+g);}}c.remove();if(Muse.assets.outOfDate.length||Muse.assets.required.length)c="Alguns arquivos no servidor podem estar ausentes ou incorretos. Limpe o cache do navegador e tente novamente. Se o problema persistir, entre em contato com o autor do site.",(d=location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi))&&Muse.assets.outOfDate.length&&(c+="\nOut of date: "+Muse.assets.outOfDate.join(",")),d&&Muse.assets.required.length&&(c+="\nMissing: "+Muse.assets.required.join(",")),alert(c)})()})();
/* body */
Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
Muse.Utils.prepHyperlinks(true);/* body */
$('#u19431').registerPositionScrollEffect([{"in":[-Infinity,48.38],"speed":[0,1]},{"in":[48.38,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19464').registerPositionScrollEffect([{"in":[-Infinity,35.38],"speed":[0,1]},{"in":[35.38,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19464').registerOpacityScrollEffect([{"fade":0,"in":[-Infinity,35.38],"opacity":100},{"in":[35.38,35.38],"opacity":100},{"fade":2,"in":[35.38,Infinity],"opacity":0}]);/* scroll effect */
$('#u19429').registerPositionScrollEffect([{"in":[-Infinity,38.38],"speed":[0,0]},{"in":[38.38,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19429').registerOpacityScrollEffect([{"fade":2,"in":[-Infinity,38.38],"opacity":0},{"in":[38.38,38.38],"opacity":100},{"fade":0,"in":[38.38,Infinity],"opacity":100}]);/* scroll effect */
Muse.Utils.initWidget('.MenuBar', function(elem) { return $(elem).museMenu(); });/* unifiedNavBar */
$('#menuu19372').registerPositionScrollEffect([{"in":[-Infinity,34.38],"speed":[0,1]},{"in":[34.38,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#menuu19372').registerOpacityScrollEffect([{"fade":0.05,"in":[-Infinity,34.38],"opacity":100},{"in":[34.38,34.38],"opacity":100},{"fade":1,"in":[34.38,Infinity],"opacity":0}]);/* scroll effect */
$('#menuu19473').registerPositionScrollEffect([{"in":[-Infinity,53.38],"speed":[0,0]},{"in":[53.38,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#menuu19473').registerOpacityScrollEffect([{"fade":20,"in":[-Infinity,53.38],"opacity":0},{"in":[53.38,53.38],"opacity":100},{"fade":0,"in":[53.38,Infinity],"opacity":100}]);/* scroll effect */
$('#u19670').registerPositionScrollEffect([{"in":[-Infinity,-68],"speed":[0,0]},{"in":[-68,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19671').registerPositionScrollEffect([{"in":[-Infinity,-68],"speed":[0,0]},{"in":[-68,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19672').registerPositionScrollEffect([{"in":[-Infinity,-68],"speed":[0,0]},{"in":[-68,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19673').registerPositionScrollEffect([{"in":[-Infinity,-68],"speed":[0,0]},{"in":[-68,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19674').registerPositionScrollEffect([{"in":[-Infinity,-68],"speed":[0,0]},{"in":[-68,Infinity],"speed":[0,0]}]);/* scroll effect */
Muse.Utils.initWidget('#widgetu19435', function(elem) { new WebPro.Widget.Form(elem, {validationEvent:'submit',errorStateSensitivity:'high',fieldWrapperClass:'fld-grp',formSubmittedClass:'frm-sub-st',formErrorClass:'frm-subm-err-st',formDeliveredClass:'frm-subm-ok-st',notEmptyClass:'non-empty-st',focusClass:'focus-st',invalidClass:'fld-err-st',requiredClass:'fld-err-st',ajaxSubmit:true}); });/* #widgetu19435 */
$('#u19677').registerPositionScrollEffect([{"in":[-Infinity,-6.37],"speed":[0,0]},{"in":[-6.37,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19677').registerOpacityScrollEffect([{"fade":285.4,"in":[-Infinity,-6.37],"opacity":0},{"in":[-6.37,-6.37],"opacity":100},{"fade":50,"in":[-6.37,Infinity],"opacity":100}]);/* scroll effect */
$('#u19675').registerPositionScrollEffect([{"in":[-Infinity,-21.93],"speed":[0,0]},{"in":[-21.93,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19675').registerOpacityScrollEffect([{"fade":319.75,"in":[-Infinity,-21.93],"opacity":0},{"in":[-21.93,-21.93],"opacity":100},{"fade":50,"in":[-21.93,Infinity],"opacity":100}]);/* scroll effect */
$('#u19679').registerPositionScrollEffect([{"in":[-Infinity,-21.93],"speed":[0,0]},{"in":[-21.93,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19679').registerOpacityScrollEffect([{"fade":401,"in":[-Infinity,-21.93],"opacity":0},{"in":[-21.93,-21.93],"opacity":100},{"fade":50,"in":[-21.93,Infinity],"opacity":100}]);/* scroll effect */
$('#u19680').registerPositionScrollEffect([{"in":[-Infinity,-18.83],"speed":[0,0]},{"in":[-18.83,Infinity],"speed":[0,0]}]);/* scroll effect */
$('#u19680').registerOpacityScrollEffect([{"fade":346.1,"in":[-Infinity,-18.83],"opacity":0},{"in":[-18.83,-18.83],"opacity":100},{"fade":0,"in":[-18.83,Infinity],"opacity":100}]);/* scroll effect */
$('#u19466').registerPositionScrollEffect([{"in":[-Infinity,1402.12],"speed":[0,1]},{"in":[1402.12,Infinity],"speed":[0,0]}]);/* scroll effect */
Muse.Utils.fullPage('#page');/* 100% height page */
Muse.Utils.showWidgetsWhenReady();/* body */
Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
} catch(e) { if (e && 'function' == typeof e.notify) e.notify(); else Muse.Assert.fail('Error calling selector function:' + e); }});
</script>
   </body>
</html>
