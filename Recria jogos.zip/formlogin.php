<!DOCTYPE html>
<?php 
session_start();

?>
<html class="html" lang="pt-BR">
 <head>

  <script type="text/javascript">
   if(typeof Muse == "undefined") window.Muse = {}; window.Muse.assets = {"required":["jquery-1.8.3.min.js", "museutils.js", "jquery.musepolyfill.bgsize.js", "jquery.scrolleffects.js", "jquery.musemenu.js", "jquery.watch.js", "webpro.js", "formlogin.css"], "outOfDate":[]};
</script>
  
  <meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
  <meta name="generator" content="2015.0.0.309"/>
    <link rel="shortcut icon" href="images/in%c3%adcio-favicon.ico?3913429556"/>
  <title>Login</title>
  <!-- CSS -->
  <link rel="stylesheet" type="text/css" href="css/site_global.css?4052507572"/>
  <link rel="stylesheet" type="text/css" href="css/formlogin.css?3985873815" id="pagesheet"/>
  <!-- Other scripts -->
  <script type="text/javascript">
   document.documentElement.className += ' js';
</script>
  <!-- JS includes -->
  <!--[if lt IE 9]>
  <script src="scripts/html5shiv.js?4241844378" type="text/javascript"></script>
  <![endif]-->
   </head>
 <body class="museBGSize">

  <div class="clearfix" id="page"><!-- group -->
   <div class="clearfix grpelem" id="ppu18950"><!-- column -->
    <div class="clearfix colelem" id="pu18950"><!-- group -->
     <div class="mse_pre_init" id="u18950" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-1,M12=0,M21=0,M22=-1,SizingMethod='auto expand')" data-mu-ie-matrix-dx="0" data-mu-ie-matrix-dy="0"><!-- rasterized frame -->
      <img id="u18950_img" alt="" width="1200" height="619" src="images/papernovo-u18950.png"/>
     </div>
     <img class="mse_pre_init ose_pre_init" id="u19009" alt="" width="222" height="197" src="images/logo%20mais%20novo%20que%20tudo23-u19009.png"/><!-- rasterized frame -->
     <img class="mse_pre_init ose_pre_init" id="u19011" alt="" width="155" height="139" src="images/logo%20mais%20novo%20que%20tudo23-u19011.png"/><!-- rasterized frame -->
    </div>
    <nav class="MenuBar clearfix ose_pre_init mse_pre_init" id="menuu18952"><!-- horizontal box -->
     <div class="MenuItemContainer clearfix grpelem" id="u25023"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u25024" href="index.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u25027" alt="Início" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19002"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19005" href="novidades.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19007" alt="Novidades" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18988"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18998" href="jogos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19001" alt="Jogos" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u19000"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u18989"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u18990"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u21926"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u21927" href="sobre-os-jogos.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u21930-4"><!-- rasterized frame --><div id="u21930-4_clip"><img id="u21930-4_img" alt="Sobre os Jogos" width="156" height="33" src="images/u21930-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18960"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18961" href="personagens.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18964" alt="Personagens" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u18963"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u18965"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u18966"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u20708"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u20711" href="sobre-os-personagens.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u20712-4"><!-- rasterized frame --><div id="u20712-4_clip"><img id="u20712-4_img" alt="Sobre os Personagens" width="214" height="31" src="images/u20712-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u24194"><!-- vertical box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u24197" href="sobre-nos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u24200" alt="Sobre Nós" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u18981"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u18982" href="compras.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u18985" alt="Compras" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
    </nav>
    <nav class="MenuBar clearfix ose_pre_init mse_pre_init" id="menuu19013"><!-- horizontal box -->
     <div class="MenuItemContainer clearfix grpelem" id="u24974"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u24975" href="index.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u24976" alt="Início" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19049"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19052" href="novidades.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19055" alt="Novidades" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19014"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19024" href="jogos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19027" alt="Jogos" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u19026"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u19015"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u19016"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u21863"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u21864" href="sobre-os-jogos.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u21865-4"><!-- rasterized frame --><div id="u21865-4_clip"><img id="u21865-4_img" alt="Sobre os Jogos" width="145" height="31" src="images/u21865-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19056"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19057" href="personagens.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19059" alt="Personagens" src="images/blank.gif"/><!-- state-based BG images --><div class="grpelem" id="u19060"><!-- image --></div></a>
      <div class="SubMenu  MenuLevel1 clearfix" id="u19061"><!-- vertical box -->
       <ul class="SubMenuView clearfix colelem" id="u19062"><!-- vertical box -->
        <li class="MenuItemContainer clearfix colelem" id="u20631"><!-- horizontal box --><a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix grpelem" id="u20632" href="sobre-os-personagens.php"><!-- horizontal box --><div class="MenuItemLabel NoWrap grpelem" id="u20634-4"><!-- rasterized frame --><div id="u20634-4_clip"><img id="u20634-4_img" alt="Sobre os Personagens" width="214" height="31" src="images/u20634-4.png"/></div></div></a></li>
       </ul>
      </div>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u24187"><!-- vertical box -->
         <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u24190" href="sobre-nos.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u24192" alt="Sobre Nós" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
     <div class="MenuItemContainer clearfix grpelem" id="u19035"><!-- vertical box -->
      <a class="nonblock nontext MenuItem MenuItemWithSubMenu clearfix colelem" id="u19036" href="compras.php"><!-- horizontal box --><img class="MenuItemLabel NoWrap grpelem" id="u19037" alt="Compras" src="images/blank.gif"/><!-- state-based BG images --></a>
     </div>
    </nav>
    <div class="mse_pre_init" id="u25423"><!-- simple frame --></div>
    <a class="nonblock nontext rounded-corners mse_pre_init" id="u25424" href="https://www.facebook.com/recriajogos"><!-- simple frame --></a>
    <a class="nonblock nontext museBGSize mse_pre_init" id="u25425" href="https://twitter.com/recriajogos"><!-- simple frame --></a>
    <a class="nonblock nontext museBGSize mse_pre_init" id="u25426" href="https://www.youtube.com/channel/UCy1YqCHq2qD1-eH30qrFOlA"><!-- simple frame --></a>
    <a class="nonblock nontext museBGSize mse_pre_init" id="u25427" href="https://recriajogos.wordpress.com/"><!-- simple frame --></a>
   </div>
   <div class="clearfix grpelem" id="ppu11653"><!-- column -->
    <div class="clearfix colelem" id="pu11653"><!-- group -->
     <img class="grpelem" id="u11653" alt="" width="546" height="599" src="images/bloco-de-notas_2252413-u11653.png"/><!-- rasterized frame -->
     <form class="form-grp clearfix grpelem" id="widgetu11726" method="post" enctype="multipart/form-data" action="Login.php"><!-- none box -->
      <div class=" clearfix grpelem" id="widgetu11735" data-required="true" data-type="email"><!-- none box -->
       <label class="fld-label grpelem" id="u11737" alt="&nbsp;Email:" src="images/blank.gif" for="widgetu11735_input"><!-- state-based BG images --></label>
       <span class="fld-input NoWrap actAsDiv rounded-corners clearfix grpelem" id="u11738-4"><!-- content --><input class="wrapped-input" type="text" spellcheck="false" id="widgetu11735_input" name="HTML_email_USUARIO" tabindex="1" required/></span>
      </div>
      <img class="grpelem" id="u11739" alt="Formulário recebido." src="images/blank.gif"/><!-- state-based BG images -->
      <input class="submit-btn NoWrap grpelem" id="u11740-17" type="submit" value="" tabindex="3"/><!-- state-based BG images -->
      <div class=" clearfix grpelem" id="widgetu11731" data-required="true"><!-- none box -->
       <label class="fld-label grpelem" id="u11733" alt="&nbsp;Senha:" src="images/blank.gif" for="widgetu11731_input"><!-- state-based BG images --></label>
       <span class="fld-input NoWrap actAsDiv rounded-corners clearfix grpelem" id="u11734-4"><!-- content --><input class="wrapped-input" type="password" id="widgetu11731_input" name="HTML_senha_USUARIO" tabindex="2" required/></span>
      </div>
     </form>
     <img class="grpelem" id="u11723" alt="" width="201" height="251" src="images/5-u11723.png"/><!-- rasterized frame -->
     <div class="grpelem" id="u11652-4" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9945,M12=0.1045,M21=-0.1045,M22=0.9945,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-3" data-mu-ie-matrix-dy="-9"><!-- rasterized frame -->
      <img id="u11652-4_img" alt="Entre" width="179" height="60" src="images/u11652-4.png"/>
     </div>
     <div class="grpelem" id="u25220" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=-0.0698,M12=-0.9976,M21=0.9976,M22=-0.0698,SizingMethod='auto expand')" data-mu-ie-matrix-dx="268" data-mu-ie-matrix-dy="-293"><!-- rasterized frame -->
      <img id="u25220_img" alt="" width="671" height="89" src="images/pencil-23648_960_720-u25220.png"/>
     </div>
    </div>
    <div class="clip_frame colelem" id="u11657"><!-- image -->
     <img class="block" id="u11657_img" src="images/folha%20com%20corte.png" alt="" width="71" height="34"/>
    </div>
   </div>
   <div class="clearfix grpelem" id="ppu19071-4"><!-- column -->
    <div class="clearfix colelem" id="pu19071-4"><!-- group -->
     <a class="nonblock nontext grpelem" id="u19071-4" href="formcadastrar.php"><!-- rasterized frame --><img id="u19071-4_img" alt="Cadastrar" width="98" height="26" src="images/u19071-4.png"/></a>
     <div class="clip_frame grpelem" id="u19072"><!-- image -->
      <img class="block" id="u19072_img" src="images/folha%20com%20corte.png" alt="" width="48" height="23"/>
     </div>
    </div>
    <div class="colelem" id="u25204" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.2419,M12=-0.9703,M21=0.9703,M22=0.2419,SizingMethod='auto expand')" data-mu-ie-matrix-dx="33" data-mu-ie-matrix-dy="-66"><!-- rasterized frame -->
     <img id="u25204_img" alt="" width="210" height="95" src="images/p993518-u25204.png"/>
    </div>
   </div>
   <a class="nonblock nontext mse_pre_init" id="u25415" href="help/index.php" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9925,M12=0.1219,M21=-0.1219,M22=0.9925,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-8" data-mu-ie-matrix-dy="-8"><!-- rasterized frame --><img id="u25415_img" alt="" width="107" height="113"  src="images/brushe-balao-de-fala-pfs-u25415.png"/></a>
   <a class="nonblock nontext MuseLinkActive grpelem" id="u19070-4" href="formlogin.php"><!-- rasterized frame --><img id="u19070-4_img" alt="Entrar" width="60" height="32" src="images/u19070-4-a.png"/></a>
   <div class="clearfix grpelem" id="pu25413"><!-- group -->
    <img class="mse_pre_init" id="u25413" alt="" width="35" height="24" src="images/folha%20com%20corte-u25413.png"/><!-- rasterized frame -->
    <div class="shadow rounded-corners mse_pre_init" id="u25417"><!-- simple frame --></div>
    <a class="nonblock nontext mse_pre_init" id="u25418" href="help/index.php"><!-- rasterized frame --><img id="u25418_img" alt="" width="164" height="149" src="images/le%c3%a3o%20final-u25418.png"/></a>
   </div>
   <div class="verticalspacer"></div>
   <div class="mse_pre_init" id="u11662" data-mu-ie-matrix="progid:DXImageTransform.Microsoft.Matrix(M11=0.9986,M12=0.0523,M21=-0.0523,M22=0.9986,SizingMethod='auto expand')" data-mu-ie-matrix-dx="-22" data-mu-ie-matrix-dy="-38"><!-- rasterized frame -->
    <img id="u11662_img" alt="" width="1459" height="885" src="images/paper10-u11662.png"/>
   </div>
  </div>
  <div class="preload_images">
   <img class="preload" src="images/u25027-a.png" alt=""/>
   <img class="preload" src="images/u19007-a.png" alt=""/>
   <img class="preload" src="images/u19001-a.png" alt=""/>
   <img class="preload" src="images/paper10.png" alt=""/>
   <img class="preload" src="images/u18964-a.png" alt=""/>
   <img class="preload" src="images/paper102.png" alt=""/>
   <img class="preload" src="images/u24200-a.png" alt=""/>
   <img class="preload" src="images/u18985-a.png" alt=""/>
   <img class="preload" src="images/u24976-a.png" alt=""/>
   <img class="preload" src="images/u19055-a.png" alt=""/>
   <img class="preload" src="images/u19027-a.png" alt=""/>
   <img class="preload" src="images/u19059-a.png" alt=""/>
   <img class="preload" src="images/u24192-a.png" alt=""/>
   <img class="preload" src="images/u19037-a.png" alt=""/>
   <img class="preload" src="images/u11737-ferr.png" alt=""/>
   <img class="preload" src="images/u11739-fss.png" alt=""/>
   <img class="preload" src="images/u11740-17-r.png" alt=""/>
   <img class="preload" src="images/u11740-17-m.png" alt=""/>
   <img class="preload" src="images/u11740-17-fs.png" alt=""/>
   <img class="preload" src="images/u11733-ferr.png" alt=""/>
  </div>
  <!-- JS includes -->
  <script type="text/javascript">
   if (document.location.protocol != 'https:') document.write('\x3Cscript src="http://musecdn.businesscatalyst.com/scripts/4.0/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script type="text/javascript">
   window.jQuery || document.write('\x3Cscript src="scripts/jquery-1.8.3.min.js" type="text/javascript">\x3C/script>');
</script>
  <script src="scripts/museutils.js?183364071" type="text/javascript"></script>
  <script src="scripts/jquery.musepolyfill.bgsize.js?4004268962" type="text/javascript"></script>
  <script src="scripts/jquery.scrolleffects.js?3860644955" type="text/javascript"></script>
  <script src="scripts/jquery.musemenu.js?3957776250" type="text/javascript"></script>
  <script src="scripts/webpro.js?3803554875" type="text/javascript"></script>
  <script src="scripts/jquery.watch.js?71412426" type="text/javascript"></script>
  <!-- Other scripts -->
  <script type="text/javascript">
   $(document).ready(function() { try {
(function(){var a={},b=function(a){if(a.match(/^rgb/))return a=a.replace(/\s+/g,"").match(/([\d\,]+)/gi)[0].split(","),(parseInt(a[0])<<16)+(parseInt(a[1])<<8)+parseInt(a[2]);if(a.match(/^\#/))return parseInt(a.substr(1),16);return 0};(function(){$('link[type="text/css"]').each(function(){var b=($(this).attr("href")||"").match(/\/?css\/([\w\-]+\.css)\?(\d+)/);b&&b[1]&&b[2]&&(a[b[1]]=b[2])})})();(function(){$("body").append('<div class="version" style="display:none; width:1px; height:1px;"></div>');
for(var c=$(".version"),d=0;d<Muse.assets.required.length;){var f=Muse.assets.required[d],g=f.match(/([\w\-\.]+)\.(\w+)$/),k=g&&g[1]?g[1]:null,g=g&&g[2]?g[2]:null;switch(g.toLowerCase()){case "css":k=k.replace(/\W/gi,"_").replace(/^([^a-z])/gi,"_$1");c.addClass(k);var g=b(c.css("color")),h=b(c.css("background-color"));g!=0||h!=0?(Muse.assets.required.splice(d,1),"undefined"!=typeof a[f]&&(g!=a[f]>>>24||h!=(a[f]&16777215))&&Muse.assets.outOfDate.push(f)):d++;c.removeClass(k);break;case "js":k.match(/^jquery-[\d\.]+/gi)&&
typeof $!="undefined"?Muse.assets.required.splice(d,1):d++;break;default:throw Error("Unsupported file type: "+g);}}c.remove();if(Muse.assets.outOfDate.length||Muse.assets.required.length)c="Alguns arquivos no servidor podem estar ausentes ou incorretos. Limpe o cache do navegador e tente novamente. Se o problema persistir, entre em contato com o autor do site.",(d=location&&location.search&&location.search.match&&location.search.match(/muse_debug/gi))&&Muse.assets.outOfDate.length&&(c+="\nOut of date: "+Muse.assets.outOfDate.join(",")),d&&Muse.assets.required.length&&(c+="\nMissing: "+Muse.assets.required.join(",")),alert(c)})()})();
/* body */
Muse.Utils.transformMarkupToFixBrowserProblemsPreInit();/* body */
Muse.Utils.prepHyperlinks(true);/* body */
$('#u18950').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,48.38]},{"speed":[0,0],"in":[48.38,Infinity]}]);/* scroll effect */
$('#u19009').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,35.38]},{"speed":[0,0],"in":[35.38,Infinity]}]);/* scroll effect */
$('#u19009').registerOpacityScrollEffect([{"in":[-Infinity,35.38],"fade":0,"opacity":100},{"opacity":100,"in":[35.38,35.38]},{"in":[35.38,Infinity],"fade":2,"opacity":0}]);/* scroll effect */
$('#u19011').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,38.38]},{"speed":[0,0],"in":[38.38,Infinity]}]);/* scroll effect */
$('#u19011').registerOpacityScrollEffect([{"in":[-Infinity,38.38],"fade":2,"opacity":0},{"opacity":100,"in":[38.38,38.38]},{"in":[38.38,Infinity],"fade":0,"opacity":100}]);/* scroll effect */
Muse.Utils.initWidget('.MenuBar', function(elem) { return $(elem).museMenu(); });/* unifiedNavBar */
$('#menuu18952').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,34.38]},{"speed":[0,0],"in":[34.38,Infinity]}]);/* scroll effect */
$('#menuu18952').registerOpacityScrollEffect([{"in":[-Infinity,34.38],"fade":0.05,"opacity":100},{"opacity":100,"in":[34.38,34.38]},{"in":[34.38,Infinity],"fade":1,"opacity":0}]);/* scroll effect */
$('#menuu19013').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,53.38]},{"speed":[0,0],"in":[53.38,Infinity]}]);/* scroll effect */
$('#menuu19013').registerOpacityScrollEffect([{"in":[-Infinity,53.38],"fade":20,"opacity":0},{"opacity":100,"in":[53.38,53.38]},{"in":[53.38,Infinity],"fade":0,"opacity":100}]);/* scroll effect */
$('#u25423').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
$('#u25424').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
$('#u25425').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
$('#u25426').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
$('#u25427').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-68]},{"speed":[0,0],"in":[-68,Infinity]}]);/* scroll effect */
Muse.Utils.initWidget('#widgetu11726', function(elem) { new WebPro.Widget.Form(elem, {validationEvent:'submit',errorStateSensitivity:'high',fieldWrapperClass:'fld-grp',formSubmittedClass:'frm-sub-st',formErrorClass:'frm-subm-err-st',formDeliveredClass:'frm-subm-ok-st',notEmptyClass:'non-empty-st',focusClass:'focus-st',invalidClass:'fld-err-st',requiredClass:'fld-err-st',ajaxSubmit:true}); });/* #widgetu11726 */
$('#u25415').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-228]},{"speed":[0,0],"in":[-228,Infinity]}]);/* scroll effect */
$('#u25413').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-232]},{"speed":[0,0],"in":[-232,Infinity]}]);/* scroll effect */
$('#u25417').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-230]},{"speed":[0,0],"in":[-230,Infinity]}]);/* scroll effect */
$('#u25418').registerPositionScrollEffect([{"speed":[0,0],"in":[-Infinity,-227]},{"speed":[0,0],"in":[-227,Infinity]}]);/* scroll effect */
$('#u11662').registerPositionScrollEffect([{"speed":[0,1],"in":[-Infinity,1390.87]},{"speed":[0,0],"in":[1390.87,Infinity]}]);/* scroll effect */
Muse.Utils.fullPage('#page');/* 100% height page */
Muse.Utils.showWidgetsWhenReady();/* body */
Muse.Utils.transformMarkupToFixBrowserProblems();/* body */
} catch(e) { if (e && 'function' == typeof e.notify) e.notify(); else Muse.Assert.fail('Error calling selector function:' + e); }});
</script>
   </body>
</html>
